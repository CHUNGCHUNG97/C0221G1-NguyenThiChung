create
    definer = root@localhost function Func_2(c_id_customer int) returns int
begin
    declare time_max int;
    set time_max = (select t.time
                    from (select max(datediff(c.date_end, c.date_start)) as time
                          from contract c
                          where c.id_customer = c_id_customer) as t);
    return time_max;
end;

