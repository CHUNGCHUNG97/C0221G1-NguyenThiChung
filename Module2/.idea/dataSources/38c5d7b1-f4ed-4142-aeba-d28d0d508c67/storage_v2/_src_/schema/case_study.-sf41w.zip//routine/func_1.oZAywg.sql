create
    definer = root@localhost function func_1(total float) returns int
begin
    declare count_service int;
    set count_service =
            (select count(id)
             from (select s.id_service as id
                   from services s
                            inner join contract c on s.id_service = c.id_service
                   group by s.id_service
                   having sum(s.rental_costs) > total) as a);
    return count_service;
end;

