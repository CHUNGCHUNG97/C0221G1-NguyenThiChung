create definer = root@localhost view information as
select `c`.`id_contract` AS `id_contract`, `s`.`id_service` AS `id_service`
from ((((`case_study`.`contract` `c` join `case_study`.`services` `s` on ((`c`.`id_service` = `s`.`id_service`))) join `case_study`.`contract_details` `cd` on ((`c`.`id_contract` = `cd`.`id_contract`))) join `case_study`.`customer` `c2` on ((`c`.`id_customer` = `c2`.`id_customer`)))
         join `case_study`.`staff` `s2` on ((`c`.`id_staff` = `s2`.`id_staff`)))
where ((year(`c`.`date_start`) between 2015 and 2019) and (`s`.`name_service` = 'room'));

