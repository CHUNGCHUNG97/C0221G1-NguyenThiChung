create
    definer = root@localhost procedure Sp_1(IN c_id_customer int)
begin
    delete
    from customer
    where id_customer = c_id_customer;
end;

