create
    definer = root@localhost procedure sp_3()
begin
    alter table contract
        drop foreign key contract_ibfk_3;
    alter table contract
        add constraint contract_ibfk_3 foreign key (id_service) references services (id_service) on delete cascade;
    delete
    from services
    where id_service = (select s.id
                        from (select s.id_service as id
                              from contract c
                                       inner join services s on c.id_service = s.id_service
                              where (year(c.date_start) between 2015 and 2019)
                                and s.name_service = 'room'
                              group by s.id_service) as s);

end;

