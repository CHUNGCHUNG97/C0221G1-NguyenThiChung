create definer = root@localhost trigger Tr_1
    after delete
    on contract
    for each row
begin

    select count(*) from contract as log into outfile 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/log.txt';
end;

