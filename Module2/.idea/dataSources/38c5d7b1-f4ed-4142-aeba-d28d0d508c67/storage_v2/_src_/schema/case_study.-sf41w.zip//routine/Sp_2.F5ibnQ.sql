create
    definer = root@localhost procedure Sp_2(IN c_id_contract int, IN c_id_staff int, IN c_id_customer int,
                                            IN c_id_service int, IN c_date_start date, IN c_date_end date,
                                            IN c_deposits float, IN c_total float)
begin
    if not exists(select c.id_contract from contract c where c.id_contract = c_id_contract)
        and exists(select s.id_staff from staff s where s.id_staff = c_id_staff)
        and exists(select ct.id_customer from customer ct where ct.id_customer = c_id_customer)
        and exists(select sv.id_service from services sv where sv.id_service = c_id_service)
    then
        insert into contract(id_staff, id_customer, id_service, date_start, date_end, deposits, total)
        VALUES (c_id_staff, c_id_customer, c_id_service, c_date_start, c_date_end, c_deposits, c_total);

    else
        SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT =
                'not success';
    end if;
end;

