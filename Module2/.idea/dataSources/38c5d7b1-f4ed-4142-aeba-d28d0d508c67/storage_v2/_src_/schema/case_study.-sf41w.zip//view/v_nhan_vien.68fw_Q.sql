create definer = root@localhost view v_nhan_vien as
select `st`.`id_staff`      AS `id_staff`,
       `st`.`name_staff`    AS `name_staff`,
       `st`.`id_position`   AS `id_position`,
       `st`.`id_level`      AS `id_level`,
       `st`.`id_part`       AS `id_part`,
       `st`.`birthday`      AS `birthday`,
       `st`.`identity_card` AS `identity_card`,
       `st`.`salary`        AS `salary`,
       `st`.`number_phone`  AS `number_phone`,
       `st`.`email`         AS `email`,
       `st`.`address`       AS `address`
from `case_study`.`staff` `st`
where ((`st`.`address` like '%Hải Châu%') and `st`.`id_staff` in (select `c2`.`id_staff`
                                                                  from `case_study`.`contract` `c2`
                                                                  where (`c2`.`date_start` = '2019-12-12')
                                                                  group by `c2`.`id_staff`));

