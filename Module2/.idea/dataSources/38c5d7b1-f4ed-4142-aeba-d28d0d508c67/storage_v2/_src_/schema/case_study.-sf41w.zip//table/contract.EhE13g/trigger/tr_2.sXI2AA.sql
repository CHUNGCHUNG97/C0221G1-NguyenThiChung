create definer = root@localhost trigger Tr_2
    before update
    on contract
    for each row
begin

    if (datediff(NEW.date_end, OLD.date_start) < 2)
    then
        SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT =
                'Ngày kết thúc hợp đồng phải lớn hơn ngày làm hợp đồng ít nhất là 2 ngày';
    else

        select concat('update success: ', id_contract)
        from contract as log
        into outfile 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/log2.txt';
    end if;
end;

