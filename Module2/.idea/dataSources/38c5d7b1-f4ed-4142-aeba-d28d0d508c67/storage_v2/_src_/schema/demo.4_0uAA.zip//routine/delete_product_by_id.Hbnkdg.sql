create
    definer = root@localhost procedure delete_product_by_id(IN p_id int)
begin
    delete
    from products
    where id = p_id;
end;

