create
    definer = root@localhost procedure find_product()
begin

    select * from products;

END;

