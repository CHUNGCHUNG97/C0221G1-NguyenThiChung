create
    definer = root@localhost procedure update_product_by_id(IN p_id int, IN p_code varchar(45), IN p_name varchar(45),
                                                            IN p_price float, IN p_amount int,
                                                            IN p_description varchar(100), IN p_status bit)
begin
    update products
    set product_code=p_code,
        product_name=p_name,
        product_price=p_price,
        product_amount=p_amount,
        product_description=p_description,
        product_status=p_status
    where id=p_id;
end;

