create
    definer = root@localhost procedure add_product(IN p_code varchar(45), IN p_name varchar(45), IN p_price float,
                                                   IN p_amount int, IN p_description varchar(100), IN p_status bit)
begin
    insert into products(product_code, product_name, product_price, product_amount, product_description, product_status)
    VALUES (p_code, p_name, p_price, p_amount, p_description, p_status);
end;

